package com.vpnblocker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer

/**
 * ============================================================
 *  CÁCH HOẠT ĐỘNG CỦA VPNService
 * ============================================================
 *
 * Android VPNService tạo ra một "tunnel" ảo (TUN interface):
 *
 *   [App gửi packet]
 *        │
 *        ▼
 *   [TUN Interface - /dev/tun0]   ← VpnService.Builder tạo ra
 *        │
 *        ▼
 *   [VpnService đọc packet]       ← Ta đọc từ FileInputStream
 *        │
 *        ▼
 *   [Xử lý: drop / forward]      ← Quyết định block hay cho qua
 *        │
 *        ▼
 *   [Ghi packet ra mạng thật]     ← Dùng "protected socket" bypass VPN
 *
 * KHI BLOCK:
 *  - Outgoing: Đọc packet từ TUN nhưng KHÔNG gửi đi → gói tin bị drop
 *  - Incoming: Không ghi packet trả về vào TUN → app không nhận được data
 *
 * ============================================================
 */
class BlockerVpnService : VpnService() {

    companion object {
        const val TAG = "BlockerVpnService"
        const val CHANNEL_ID = "vpn_channel"
        const val NOTIF_ID = 1

        // Actions gửi từ MainActivity
        const val ACTION_START   = "ACTION_START"
        const val ACTION_STOP    = "ACTION_STOP"

        // Extras để truyền cấu hình
        const val EXTRA_BLOCK_OUTGOING = "block_outgoing"
        const val EXTRA_BLOCK_INCOMING = "block_incoming"

        // Broadcast để báo trạng thái về UI
        const val ACTION_STATUS = "com.vpnblocker.STATUS"
        const val EXTRA_RUNNING = "running"
    }

    private var vpnInterface: ParcelFileDescriptor? = null
    private var workerThread: Thread? = null

    @Volatile private var isRunning = false
    @Volatile private var blockOutgoing = true
    @Volatile private var blockIncoming = true

    // ─────────────────────────────────────────
    //  Service Lifecycle
    // ─────────────────────────────────────────

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                blockOutgoing = intent.getBooleanExtra(EXTRA_BLOCK_OUTGOING, true)
                blockIncoming = intent.getBooleanExtra(EXTRA_BLOCK_INCOMING, true)
                startVpn()
            }
            ACTION_STOP -> stopVpn()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }

    override fun onRevoke() {
        // Gọi khi user thu hồi quyền VPN từ Settings
        stopVpn()
        super.onRevoke()
    }

    // ─────────────────────────────────────────
    //  Khởi động VPN Tunnel
    // ─────────────────────────────────────────

    private fun startVpn() {
        if (isRunning) return

        Log.d(TAG, "Starting VPN | blockOut=$blockOutgoing | blockIn=$blockIncoming")

        /*
         * VpnService.Builder xây dựng TUN interface:
         *
         * .addAddress("10.0.0.2", 32)
         *    → IP ảo của thiết bị trong tunnel
         *
         * .addRoute("0.0.0.0", 0)
         *    → Route TẤT CẢ traffic qua tunnel (default route)
         *    → Để chặn app cụ thể dùng .addAllowedApplication() / .addDisallowedApplication()
         *
         * .addDnsServer("8.8.8.8")
         *    → DNS server cho tunnel
         *
         * .setMtu(1500)
         *    → Maximum Transmission Unit - kích thước gói tối đa
         *
         * .establish()
         *    → Trả về ParcelFileDescriptor - file descriptor của TUN device
         *    → Đọc/ghi file này = đọc/ghi packet mạng
         */
        vpnInterface = Builder()
            .addAddress("10.0.0.2", 32)
            .addRoute("0.0.0.0", 0)
            .addRoute("::", 0)                     // IPv6
            .addDnsServer("8.8.8.8")
            .addDnsServer("8.8.4.4")
            .setMtu(1500)
            .setSession("VPN Blocker")
            .also {
                // Không chặn chính app của mình (tránh vòng lặp)
                it.addDisallowedApplication(packageName)
            }
            .establish()

        if (vpnInterface == null) {
            Log.e(TAG, "Failed to establish VPN interface")
            broadcastStatus(false)
            return
        }

        isRunning = true
        startForegroundNotification()
        broadcastStatus(true)

        // Chạy packet processing trên thread riêng
        workerThread = Thread({ processPackets() }, "VPN-Worker").apply { start() }
    }

    // ─────────────────────────────────────────
    //  Vòng lặp xử lý Packet (CORE LOGIC)
    // ─────────────────────────────────────────

    private fun processPackets() {
        val fd = vpnInterface?.fileDescriptor ?: return

        /*
         * FileInputStream  → đọc packet từ TUN (packet outgoing từ device)
         * FileOutputStream → ghi packet vào TUN (packet incoming cho app)
         *
         * BLOCK OUTGOING:
         *   Đọc packet từ `input` nhưng KHÔNG gửi đến server thực
         *   → Gói tin bị nuốt (dropped), không bao giờ rời thiết bị
         *
         * BLOCK INCOMING:
         *   Không ghi response vào `output`
         *   → App không nhận được dữ liệu trả về
         *
         * ALLOW (forward mode - chỉ demo):
         *   Dùng protect(socket) để tạo socket bypass tunnel,
         *   sau đó forward packet ra internet thật và ghi response về.
         */
        val input  = FileInputStream(fd)
        val output = FileOutputStream(fd)
        val buffer = ByteBuffer.allocate(32767)

        Log.d(TAG, "Packet processing loop started")

        while (isRunning) {
            try {
                buffer.clear()
                val length = input.read(buffer.array())

                if (length <= 0) {
                    Thread.sleep(10)
                    continue
                }

                val packet = buffer.array().copyOf(length)
                val info   = parseIpHeader(packet)

                Log.v(TAG, "Packet: ${info.srcIp}:${info.srcPort} → ${info.dstIp}:${info.dstPort} | proto=${info.protocol} | len=$length")

                if (blockOutgoing) {
                    // DROP: không làm gì cả → packet bị mất
                    Log.d(TAG, "BLOCKED outgoing packet to ${info.dstIp}:${info.dstPort}")
                    continue
                }

                /*
                 * NẾU MUỐN FORWARD (không block):
                 * 1. Tạo DatagramSocket / Socket thông thường
                 * 2. Gọi protect(socket) → socket này bypass VPN tunnel
                 * 3. Gửi packet đến server thực
                 * 4. Nhận response
                 * 5. Ghi response vào `output` để app nhận được
                 *
                 * Trong demo này ta CHỈ block, không forward.
                 * Nếu muốn VPN thực sự (như WireGuard/OpenVPN),
                 * bước này sẽ encrypt và gửi đến VPN server.
                 */

                if (!blockIncoming) {
                    // Chỉ ghi lại nếu không block incoming
                    // (Trong full implementation: ghi response từ server về đây)
                    output.write(packet, 0, length)
                }

            } catch (e: InterruptedException) {
                break
            } catch (e: Exception) {
                if (isRunning) Log.e(TAG, "Packet processing error", e)
                break
            }
        }

        Log.d(TAG, "Packet processing loop ended")
    }

    // ─────────────────────────────────────────
    //  Parse IP Header (debug info)
    // ─────────────────────────────────────────

    private data class PacketInfo(
        val version: Int,
        val protocol: String,
        val srcIp: String,
        val dstIp: String,
        val srcPort: Int,
        val dstPort: Int
    )

    private fun parseIpHeader(packet: ByteArray): PacketInfo {
        if (packet.isEmpty()) return PacketInfo(0, "?", "?", "?", 0, 0)

        val version = (packet[0].toInt() and 0xFF) shr 4

        return if (version == 4 && packet.size >= 20) {
            // IPv4
            val ihl = (packet[0].toInt() and 0x0F) * 4
            val proto = when (packet[9].toInt() and 0xFF) {
                6  -> "TCP"
                17 -> "UDP"
                1  -> "ICMP"
                else -> packet[9].toString()
            }
            val srcIp = "${packet[12].toInt() and 0xFF}.${packet[13].toInt() and 0xFF}.${packet[14].toInt() and 0xFF}.${packet[15].toInt() and 0xFF}"
            val dstIp = "${packet[16].toInt() and 0xFF}.${packet[17].toInt() and 0xFF}.${packet[18].toInt() and 0xFF}.${packet[19].toInt() and 0xFF}"
            val srcPort = if (packet.size > ihl + 1) ((packet[ihl].toInt() and 0xFF) shl 8) or (packet[ihl + 1].toInt() and 0xFF) else 0
            val dstPort = if (packet.size > ihl + 3) ((packet[ihl + 2].toInt() and 0xFF) shl 8) or (packet[ihl + 3].toInt() and 0xFF) else 0
            PacketInfo(4, proto, srcIp, dstIp, srcPort, dstPort)
        } else if (version == 6 && packet.size >= 40) {
            // IPv6 (simplified)
            PacketInfo(6, "IPv6", "::src", "::dst", 0, 0)
        } else {
            PacketInfo(version, "?", "?", "?", 0, 0)
        }
    }

    // ─────────────────────────────────────────
    //  Dừng VPN
    // ─────────────────────────────────────────

    private fun stopVpn() {
        Log.d(TAG, "Stopping VPN")
        isRunning = false
        workerThread?.interrupt()
        workerThread = null

        try {
            vpnInterface?.close()
        } catch (e: Exception) {
            Log.e(TAG, "Error closing VPN interface", e)
        }
        vpnInterface = null

        stopForeground(true)
        stopSelf()
        broadcastStatus(false)
    }

    // ─────────────────────────────────────────
    //  Foreground Notification (bắt buộc API 26+)
    // ─────────────────────────────────────────

    private fun startForegroundNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "VPN Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "VPN Blocker đang hoạt động" }

            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }

        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, BlockerVpnService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val blockDesc = buildList {
            if (blockOutgoing) add("⬆ Outgoing")
            if (blockIncoming) add("⬇ Incoming")
        }.joinToString(" + ").ifEmpty { "Monitoring only" }

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("🔒 VPN Blocker Active")
            .setContentText("Blocking: $blockDesc")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_delete, "Stop VPN", stopIntent)
            .build()

        startForeground(NOTIF_ID, notification)
    }

    // ─────────────────────────────────────────
    //  Broadcast trạng thái về MainActivity
    // ─────────────────────────────────────────

    private fun broadcastStatus(running: Boolean) {
        sendBroadcast(Intent(ACTION_STATUS).apply {
            putExtra(EXTRA_RUNNING, running)
        })
    }
}
