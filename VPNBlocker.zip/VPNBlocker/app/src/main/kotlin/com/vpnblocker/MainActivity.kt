package com.vpnblocker

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.VpnService
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.vpnblocker.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    companion object {
        const val TAG = "MainActivity"
        const val VPN_REQUEST_CODE = 100
    }

    private lateinit var binding: ActivityMainBinding
    private var isVpnRunning = false

    // ─────────────────────────────────────────
    //  BroadcastReceiver nhận trạng thái từ Service
    // ─────────────────────────────────────────

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val running = intent.getBooleanExtra(BlockerVpnService.EXTRA_RUNNING, false)
            updateUI(running)
        }
    }

    // ─────────────────────────────────────────
    //  Lifecycle
    // ─────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupUI()
        registerReceiver(
            statusReceiver,
            IntentFilter(BlockerVpnService.ACTION_STATUS),
            RECEIVER_NOT_EXPORTED
        )
    }

    override fun onDestroy() {
        unregisterReceiver(statusReceiver)
        super.onDestroy()
    }

    // ─────────────────────────────────────────
    //  Cài đặt UI
    // ─────────────────────────────────────────

    private fun setupUI() {
        // Mặc định bật cả hai
        binding.switchBlockOutgoing.isChecked = true
        binding.switchBlockIncoming.isChecked = true

        binding.btnToggleVpn.setOnClickListener {
            if (isVpnRunning) {
                stopVpn()
            } else {
                requestVpnPermission()
            }
        }

        updateUI(false)
    }

    private fun updateUI(running: Boolean) {
        isVpnRunning = running

        binding.btnToggleVpn.text = if (running) "⏹ STOP VPN" else "▶ START VPN"
        binding.tvStatus.text = if (running) "🟢 VPN đang chạy" else "🔴 VPN đã dừng"

        // Disable switches khi VPN đang chạy
        binding.switchBlockOutgoing.isEnabled = !running
        binding.switchBlockIncoming.isEnabled = !running

        val blockDesc = buildList {
            if (running) {
                if (binding.switchBlockOutgoing.isChecked) add("⬆ Chặn gửi")
                if (binding.switchBlockIncoming.isChecked) add("⬇ Chặn nhận")
            }
        }.joinToString("\n").ifEmpty { if (running) "Chỉ giám sát" else "—" }

        binding.tvBlockInfo.text = if (running) "Đang chặn:\n$blockDesc" else ""
    }

    // ─────────────────────────────────────────
    //  Xin quyền VPN
    // ─────────────────────────────────────────

    private fun requestVpnPermission() {
        /*
         * VpnService.prepare() kiểm tra:
         * - Nếu trả về null → App đã được cấp quyền VPN (hoặc là lần đầu)
         * - Nếu trả về Intent → Cần hiển thị dialog xin quyền hệ thống
         *
         * Dialog hệ thống sẽ hỏi:
         * "Ứng dụng X muốn tạo kết nối VPN..."
         * User phải bấm OK mới chạy được.
         */
        val intent = VpnService.prepare(this)
        if (intent != null) {
            Log.d(TAG, "Requesting VPN permission...")
            @Suppress("DEPRECATION")
            startActivityForResult(intent, VPN_REQUEST_CODE)
        } else {
            // Đã có quyền, bắt đầu luôn
            Log.d(TAG, "VPN permission already granted")
            startVpn()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == VPN_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                Log.d(TAG, "VPN permission granted by user")
                startVpn()
            } else {
                Log.w(TAG, "VPN permission denied by user")
                Toast.makeText(this, "Cần quyền VPN để hoạt động!", Toast.LENGTH_LONG).show()
            }
        }
    }

    // ─────────────────────────────────────────
    //  Start / Stop VPN Service
    // ─────────────────────────────────────────

    private fun startVpn() {
        val blockOutgoing = binding.switchBlockOutgoing.isChecked
        val blockIncoming = binding.switchBlockIncoming.isChecked

        if (!blockOutgoing && !blockIncoming) {
            Toast.makeText(this, "Hãy chọn ít nhất một loại block!", Toast.LENGTH_SHORT).show()
            return
        }

        Log.d(TAG, "Starting VPN service | blockOut=$blockOutgoing | blockIn=$blockIncoming")

        val intent = Intent(this, BlockerVpnService::class.java).apply {
            action = BlockerVpnService.ACTION_START
            putExtra(BlockerVpnService.EXTRA_BLOCK_OUTGOING, blockOutgoing)
            putExtra(BlockerVpnService.EXTRA_BLOCK_INCOMING, blockIncoming)
        }
        startService(intent)
    }

    private fun stopVpn() {
        Log.d(TAG, "Stopping VPN service")
        val intent = Intent(this, BlockerVpnService::class.java).apply {
            action = BlockerVpnService.ACTION_STOP
        }
        startService(intent)
    }
}
